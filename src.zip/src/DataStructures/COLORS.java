package DataStructures;

public enum COLORS {
    WHITE,
    GRAY,
    BLACK
}
